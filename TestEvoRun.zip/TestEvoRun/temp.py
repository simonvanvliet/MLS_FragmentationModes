#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  2 13:10:18 2020

@author: simonvanvliet
vanvliet@zoology.ubc.ca
"""


rpInt = 5.    
nextRepT = 5.    
    
for i in range(10):
    print('next t = %i' %nextRepT)
    nextRepT = nextRepT + rpInt
